package PaymentMethodsActivityStarter.Result.Companion;

public class SUCCEEDED {
}
