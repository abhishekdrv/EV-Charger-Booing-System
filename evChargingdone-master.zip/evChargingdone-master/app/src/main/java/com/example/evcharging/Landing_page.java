package com.example.evcharging;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Landing_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);
    }
}